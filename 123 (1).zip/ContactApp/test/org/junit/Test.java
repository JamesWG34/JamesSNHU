package org.junit;

public class Test {

}
