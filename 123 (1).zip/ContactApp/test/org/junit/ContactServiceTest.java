package org.junit;

import static org.junit.Assert.*;

import com.contacts.Contact;
import com.contacts.ContactService;

public class ContactServiceTest {

    @Test
    public void testAddContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);

        assertTrue(contactService.getContacts().containsKey(contact.getContactID()));
    }

    @Test
    public void testDeleteContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);

        contactService.deleteContact(contact.getContactID());

        assertFalse(contactService.getContacts().containsKey(contact.getContactID()));
    }

    
}
