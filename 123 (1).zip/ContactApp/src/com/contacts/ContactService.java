package com.contacts;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private Map<String, Contact> contacts;

    public ContactService() {
        this.contacts = new HashMap<>();
    }

    public void addContact(Contact contact) {
        contacts.put(contact.getContactID(), contact);
    }

    public void deleteContact(String contactID) {
        contacts.remove(contactID);
    }

    public void updateContact(String contactID, String firstName, String lastName, String phone, String address) {
        if (!contacts.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact with ID " + contactID + " does not exist");
        }

        Contact contact = contacts.get(contactID);

        if (firstName != null && !firstName.isEmpty()) {
            if (firstName.length() > 10) {
                throw new IllegalArgumentException("First name cannot be longer than 10 characters");
            }
            contact.setFirstName(firstName);
        }

        if (lastName != null && !lastName.isEmpty()) {
            if (lastName.length() > 10) {
                throw new IllegalArgumentException("Last name cannot be longer than 10 characters");
            }
            contact.setLastName(lastName);
        }

        if (phone != null && !phone.isEmpty()) {
            if (phone.length() != 10) {
                throw new IllegalArgumentException("Phone number must be exactly 10 digits");
            }
            contact.setPhone(phone);
        }

        if (address != null && !address.isEmpty()) {
            if (address.length() > 30) {
                throw new IllegalArgumentException("Address cannot be longer than 30 characters");
            }
            contact.setAddress(address);
        }
    }

    public Map<String, Contact> getContacts() {
        return contacts;
    }
}
