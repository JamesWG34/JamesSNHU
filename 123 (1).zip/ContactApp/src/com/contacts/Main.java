package com.contacts;

public class Main {
    public static void main(String[] args) {
        // Creating a Contact
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");

        // Creating a ContactService and adding the contact
        ContactService contactService = new ContactService();
        contactService.addContact(contact);

        // Retrieving and printing contacts
        System.out.println("Contacts:");
        for (Contact c : contactService.getContacts().values()) {
            System.out.println(c.getFirstName() + " " + c.getLastName() + " - " + c.getPhone());
        }
    }
}
