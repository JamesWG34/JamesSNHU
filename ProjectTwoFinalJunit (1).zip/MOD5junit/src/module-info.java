/**
 * 
 */
/**
 * 
 */
module MOD5junit {
	requires junit;
}