package com.company.app;

//Main.java
import java.util.Date;

public class Main {
 public static void main(String[] args) {
     // Creating an appointment
     Appointment appointment = new Appointment("1", new Date(), "Meeting with client");
     
     // Creating an appointment service
     AppointmentService appointmentService = new AppointmentService();
     
     // Adding appointment to the appointment service
     appointmentService.addAppointment(appointment);
     
     // Retrieving appointment by ID
     Appointment retrievedAppointment = appointmentService.getAppointmentById("1");
     System.out.println("Retrieved Appointment: " + retrievedAppointment.getDescription());
     
     // Deleting appointment
     appointmentService.deleteAppointment("1");
     System.out.println("Appointment deleted successfully");
 }
}
