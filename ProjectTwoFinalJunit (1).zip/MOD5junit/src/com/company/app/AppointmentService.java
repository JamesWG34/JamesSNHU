package com.company.app;

//AppointmentService.java
import java.util.*;

public class AppointmentService {
 private Map<String, Appointment> appointments;

 public AppointmentService() {
     this.appointments = new HashMap<>();
 }

 public void addAppointment(Appointment appointment) {
     appointments.put(appointment.getAppointmentId(), appointment);
 }

 public void deleteAppointment(String appointmentId) {
     appointments.remove(appointmentId);
 }

 public Appointment getAppointmentById(String appointmentId) {
     return appointments.get(appointmentId);
 }
}
