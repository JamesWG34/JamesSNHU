package com.company.app;

import static org.junit.Assert.*;

import org.junit.Test;
import java.util.Date;

public class AppointmentServiceTest {
    @Test
    public void testAddAppointment() {
        AppointmentService appointmentService = new AppointmentService();
        Appointment appointment = new Appointment("1", new Date(), "Test Description");
        appointmentService.addAppointment(appointment);
        assertEquals(appointment, appointmentService.getAppointmentById("1"));
    }

    @Test
    public void testDeleteAppointment() {
        AppointmentService appointmentService = new AppointmentService();
        Appointment appointment = new Appointment("1", new Date(), "Test Description");
        appointmentService.addAppointment(appointment);
        appointmentService.deleteAppointment("1");
        assertNull(appointmentService.getAppointmentById("1"));
    }

   
}
