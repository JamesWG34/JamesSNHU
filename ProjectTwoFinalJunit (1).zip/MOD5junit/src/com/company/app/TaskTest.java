package com.company.app;
import static org.junit.Assert.*;
import org.junit.Test;
public class TaskTest {

    @Test
    public void testTaskCreation() {
        Task task = new Task("123", "Task Name", "Task Description");
        assertNotNull(task);
        assertEquals("123", task.getTaskId());
        assertEquals("Task Name", task.getName());
        assertEquals("Task Description", task.getDescription());
    }
}