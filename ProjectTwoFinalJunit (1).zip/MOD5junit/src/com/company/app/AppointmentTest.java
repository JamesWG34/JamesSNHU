package com.company.app;
import java.util.Date;
import static org.junit.Assert.*;

import org.junit.Test;

public class AppointmentTest {
    @Test
    public void testAppointmentIdLength() {
        // Test appointment ID length
        Appointment appointment = new Appointment("1234567890", new Date(), "Test Description");
        assertEquals("1234567890", appointment.getAppointmentId());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAppointmentIdLengthExceeded() {
        // Test appointment ID length exceeded
        new Appointment("12345678901", new Date(), "Test Description");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAppointmentIdNull() {
        // Test appointment ID null
        new Appointment(null, new Date(), "Test Description");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAppointmentDateInPast() {
        // Test appointment date in the past
        new Appointment("1", new Date(System.currentTimeMillis() - 1000), "Test Description");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAppointmentDateNull() {
        // Test appointment date null
        new Appointment("1", null, "Test Description");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDescriptionNull() {
        // Test description null
        new Appointment("1", new Date(), null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDescriptionLengthExceeded() {
        // Test description length exceeded
        new Appointment("1", new Date(), "This is a very long description that exceeds the maximum allowed length of 50 characters");
    }
}