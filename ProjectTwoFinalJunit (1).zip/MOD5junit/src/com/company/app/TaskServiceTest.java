package com.company.app;
import static org.junit.Assert.*;
import org.junit.Test;
public class TaskServiceTest {

    @Test
    public void testAddTask() {
        TaskService taskService = new TaskService();
        Task task = new Task("123", "Task Name", "Task Description");
        taskService.addTask(task);
        assertEquals(task, taskService.getTaskById("123"));
    }

    @Test
    public void testDeleteTask() {
        TaskService taskService = new TaskService();
        Task task = new Task("123", "Task Name", "Task Description");
        taskService.addTask(task);
        taskService.deleteTask("123");
        assertNull(taskService.getTaskById("123"));
    }

    @Test
    public void testUpdateTaskName() {
        TaskService taskService = new TaskService();
        Task task = new Task("123", "Task Name", "Task Description");
        taskService.addTask(task);
        taskService.updateTaskName("123", "New Task Name");
        assertEquals("New Task Name", taskService.getTaskById("123").getName());
    }

    @Test
    public void testUpdateTaskDescription() {
        TaskService taskService = new TaskService();
        Task task = new Task("123", "Task Name", "Task Description");
        taskService.addTask(task);
        taskService.updateTaskDescription("123", "New Task Description");
        assertEquals("New Task Description", taskService.getTaskById("123").getDescription());
    }
}