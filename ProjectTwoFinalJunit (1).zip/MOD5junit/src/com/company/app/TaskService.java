package com.company.app;
import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private Map<String, Task> tasks;

    // Constructor
    public TaskService() {
        this.tasks = new HashMap<>();
    }

    // Method to add a task
    public void addTask(Task task) {
        tasks.put(task.getTaskId(), task);
    }

    // Method to delete a task
    public void deleteTask(String taskId) {
        tasks.remove(taskId);
    }

    // Method to update name of a task
    public void updateTaskName(String taskId, String newName) {
        if (tasks.containsKey(taskId)) {
            Task task = tasks.get(taskId);
            task.setName(newName);
        }
    }

    // Method to update description of a task
    public void updateTaskDescription(String taskId, String newDescription) {
        if (tasks.containsKey(taskId)) {
            Task task = tasks.get(taskId);
            task.setDescription(newDescription);
        }
    }

    // Method to get a task by ID
    public Task getTaskById(String taskId) {
        return tasks.get(taskId);
    }
}