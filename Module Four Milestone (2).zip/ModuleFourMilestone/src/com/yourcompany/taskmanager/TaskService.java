package com.yourcompany.taskmanager;

public class TaskService {

}
