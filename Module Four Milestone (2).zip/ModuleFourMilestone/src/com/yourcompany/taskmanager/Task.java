package com.yourcompany.taskmanager;

public class Task {

}
