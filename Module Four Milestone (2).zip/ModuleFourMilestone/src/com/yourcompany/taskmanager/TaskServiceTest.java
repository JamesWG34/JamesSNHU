package com.yourcompany.taskmanager;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {

 @Test
 public void testAddTask() {
     TaskService taskService = new TaskService();
     Task task = new Task("T123", "Task Name", "Task Description");

     taskService.addTask(task);
     assertEquals(task, taskService.getTask("T123"));
 }

 @Test
 public void testDeleteTask() {
     TaskService taskService = new TaskService();
     Task task = new Task("T123", "Task Name", "Task Description");

     taskService.addTask(task);
     taskService.deleteTask("T123");
     assertNull(taskService.getTask("T123"));
 }

 @Test
 public void testUpdateTaskName() {
     TaskService taskService = new TaskService();
     Task task = new Task("T123", "Task Name", "Task Description");

     taskService.addTask(task);
     taskService.updateTaskName("T123", "Updated Task Name");
     assertEquals("Updated Task Name", taskService.getTask("T123").getName());
 }

 @Test
 public void testUpdateTaskDescription() {
     TaskService taskService = new TaskService();
     Task task = new Task("T123", "Task Name", "Task Description");

     taskService.addTask(task);
     taskService.updateTaskDescription("T123", "Updated Task Description");
     assertEquals("Updated Task Description", taskService.getTask("T123").getDescription());
 }
}
